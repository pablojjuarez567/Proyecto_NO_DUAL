package com.example.bottomnavbar

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView
import androidx.recyclerview.widget.RecyclerView
import com.example.bottomnavbar.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private var adapterBandera: CardAdapter? = null
    private var listaProyectos: MutableList<Proyecto> = rellenarProyectos()
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        this.recarga()
        adapterBandera = CardAdapter(this, R.layout.cartas, listaProyectos)
    }

    private fun recarga() {
        val adapter = CardAdapter(
            this,
            R.layout.cartas, listaProyectos
        )

        binding.lista.adapter = adapter
    }

    private fun rellenarProyectos(): MutableList<Proyecto> {
        val listado: MutableList<Proyecto> = mutableListOf()

        for (i in 1..10) {

            listado.add(Proyecto("Proyecto $i"))
        }

        return listado
    }
}