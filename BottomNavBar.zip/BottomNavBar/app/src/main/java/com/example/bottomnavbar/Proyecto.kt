package com.example.bottomnavbar

class Proyecto(var texto:String)